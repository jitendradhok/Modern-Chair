Modern Chair Project:
This project showcases a modern chair product page created using HTML and CSS. It features a responsive layout and interactive elements.

Features:

Product Information: Displays details about the modern chair, including its name, price, description, and specifications.

Color Selection: Allows users to choose from different color options for the chair.

Image Display: Shows images of the chair corresponding to the selected color.

Add to Cart Button: Provides a button to add the chair to the shopping cart.
